<?php 


$servername = "localhost";
$username = "root";
$password = "";
$dbname="shaheen";
$conn = mysqli_connect($servername, $username, $password,$dbname);

if(!$conn){
    die('connectoion failed:'. mysqli_connect_errno());
} else{
//    echo "wecldfsdf";
}
    
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

$_SESSION["payment_data"]="";
$_SESSION["payment_data"] = $_REQUEST;
$last_id = $conn->insert_id;
echo $last_id; 



?>
<a href="http://www.alshaheen.com.kw/demo/home/invoice">Show Invoice</a>
</body>
</html>

